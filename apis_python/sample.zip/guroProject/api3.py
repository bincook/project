import requests
import xmltodict
import json

# 건강보험심사평가원_코로나19병원정보(국민안심병원 외)서비스
# API 사이트 : https://www.data.go.kr/tcs/dss/selectApiDataDetailView.do?publicDataPk=15043078

url = 'http://apis.data.go.kr/B551182/pubReliefHospService/getpubReliefHospList?'
serviceKey = 'serviceKey=Z9bsijxgPdovM7xlVFn4UQuqlttpM361%2Bt9lxtVewfXvIWHKOlTLbXQC%2BC6mFgWE%2FR7dkFJgsVmxsoZZxFy9FA%3D%3D'
pageNo = '&pageNo=1'
numOfRows = '&numOfRows=269'  # max: 269
spclAdmTyCd = '&spclAdmTyCd=A0'  # A0: 국민안심병원, 97: 코로나검사 실시기관, 99: 코로나 선별진료소 운영기관

res = requests.get(url + serviceKey + pageNo + numOfRows + spclAdmTyCd)
print(res)
print(res.text)

dictRes = xmltodict.parse(res.text)
print(dictRes)

jsonRes = json.dumps(dictRes, ensure_ascii=False)
print(jsonRes)

items = dictRes['response']['body']['items']['item']

with open('./response3-2.csv', mode='w', encoding='utf-8-sig') as f:
    head = '시도명 (sidoNm), 시군구명 (sgguNm), 기관명 (yadmNm), 선정유형 (hospTyTpCd), 전화번호(telno), 운영가능일자 (adtFrDd) , 구분코드 (spclAdmTyCd)\n'
    f.write(head)

    for item in items:
        adtFrDd = item.get('adtFrDd')
        hospTyTpCd = item.get('hospTyTpCd')
        sgguNm = item.get('sgguNm')
        sidoNm = item.get('sidoNm')
        spclAdmTyCd = item.get('spclAdmTyCd')
        telno = item.get('telno')
        yadmNm = item.get('yadmNm')

        f.write('{}, {}, {}, {}, {}, {}, {}\n'.format(
            sidoNm,
            sgguNm,
            yadmNm,
            hospTyTpCd,
            telno,
            adtFrDd,
            spclAdmTyCd,
        ))
