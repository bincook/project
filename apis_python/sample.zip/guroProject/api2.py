import json
import requests
import csv

# 공공데이터활용지원센터_코로나19 예방접종센터 조회서비스
# API 사이트 : https://www.data.go.kr/tcs/dss/selectApiDataDetailView.do?publicDataPk=15077586

url = 'https://api.odcloud.kr/api/15077586/v1/centers?'
serviceKey = 'serviceKey=Z9bsijxgPdovM7xlVFn4UQuqlttpM361%2Bt9lxtVewfXvIWHKOlTLbXQC%2BC6mFgWE%2FR7dkFJgsVmxsoZZxFy9FA%3D%3D'
page = '&page=1'
perPage = '&perPage=284'  # max: 284

res = requests.get(url + serviceKey + page + perPage)
print(res)

dictRes = json.loads(res.text)
print(dictRes)

items = dictRes['data']

with open('./response2.csv', mode='w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    head = '번호 (id),예방 접종 센터명 (centerName),시도 (sido),시군구 (sigungu),시설명 (facilityName),우편번호 (zipCode),주소 (address),위도 (lat),경도 (lng),생성일 (createdAt),수정일 (updatedAt),예방 접종 센터 유형 (centerType),운영 기관 (org),사무실 전화번호 (phoneNumber)'
    writer.writerow(head.split(','))

    for item in items:
        address = item['address']
        centerName = item['centerName']
        centerType = item['centerType']
        createdAt = item['createdAt']
        facilityName = item['facilityName']
        id = item['id']
        lat = item['lat']
        lng = item['lng']
        org = item['org']
        phoneNumber = item['phoneNumber']
        sido = item['sido']
        sigungu = item['sigungu']
        updatedAt = item['updatedAt']
        zipCode = item['zipCode']

        writer.writerow(
            [
                id,
                centerName,
                sido,
                sigungu,
                facilityName,
                zipCode,
                address,
                lat,
                lng,
                createdAt,
                updatedAt,
                centerType,
                org,
                phoneNumber
            ]
        )
