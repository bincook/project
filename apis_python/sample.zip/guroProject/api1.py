import requests
import xmltodict
import json

# 공공데이터활용지원센터_보건복지부 코로나19 감염 현황
# API 사이트 : https://www.data.go.kr/tcs/dss/selectApiDataDetailView.do?publicDataPk=15043376

url = 'http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19InfStateJson?'
serviceKey = 'serviceKey=Z9bsijxgPdovM7xlVFn4UQuqlttpM361%2Bt9lxtVewfXvIWHKOlTLbXQC%2BC6mFgWE%2FR7dkFJgsVmxsoZZxFy9FA%3D%3D'
pageNo = '&pageNo=1'
numOfRows = '&numOfRows=10'
startCreateDt = '&startCreateDt=20200131'
endCreateDt = '&endCreateDt=20210830'

res = requests.get(url + serviceKey + pageNo + numOfRows + startCreateDt + endCreateDt)
print(res)
print(res.text)

dictRes = xmltodict.parse(res.text)
print(dictRes)

jsonRes = json.dumps(dictRes)
print(jsonRes)

items = dictRes['response']['body']['items']['item']

with open('./response1.csv', mode='w', encoding='utf-8-sig') as f:
    head = '번호 (seq), 기준일 (stateDt), 기준시간 (stateTime), 확진자 수 (decideCnt), 격리해제 수 (clearCnt), 검사진행 수 (examCnt), 사망자 수 (deathCnt), 치료중 환자 수 (careCnt), 결과 음성 수 (resutlNegCnt), 누적 검사 수 (accExamCnt), 누적 검사 완료 수 (accExamCompCnt), 누적 확진률 (accDefRate), 등록일시분초 (createDt),  수정일시분초 (updateDt)\n'
    f.write(head)

    for item in items:
        seq = item['seq']
        accDefRate = item.get('accDefRate')
        accExamCnt = item.get('accExamCnt')
        accExamCompCnt = item.get('accExamCompCnt')
        careCnt = item.get('careCnt')
        clearCnt = item.get('clearCnt')
        createDt = item.get('createDt')
        deathCnt = item.get('deathCnt')
        decideCnt = item.get('decideCnt')
        examCnt = item.get('examCnt')
        resutlNegCnt = item.get('resutlNegCnt')
        stateDt = item.get('stateDt')
        stateTime = item.get('stateTime')
        updateDt = item.get('updateDt')

        f.write('{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}\n'.format(
            seq,
            stateDt,
            stateTime,
            decideCnt,
            clearCnt,
            examCnt,
            deathCnt,
            careCnt,
            resutlNegCnt,
            accExamCnt,
            accExamCompCnt,
            accDefRate,
            createDt,
            updateDt
        ))
