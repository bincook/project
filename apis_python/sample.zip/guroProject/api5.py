import requests
import json
import csv

# Corona-19-API
# API 사이트 : https://github.com/dhlife09/Corona-19-API

url = 'https://api.corona-19.kr/korea/country/new/?'
serviceKey = 'serviceKey=9kcdxuvKJWHmstOI8h2plBCPngrUR7NwZ'

res = requests.get(url + serviceKey)
print(res)
print(res.text)

items = json.loads(res.text)

with open('./response5.csv', mode='w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)

    writer.writerow([
        '시도명 (countryName)',
        '신규확진환자수 (newCase)',
        '확진환자수 (totalCase)',
        '완치자수 (recovered)',
        '사망자 (death)',
        '발생률 % (percentage)',
        '전일대비증감-해외유입 (newCcase)',
        '전일대비증감-지역발생 (newFcase)'
    ])

    for item in items.values():
        if type(item) != dict:
            continue

        countryName = item['countryName']
        newCase = item['newCase']
        totalCase = item['totalCase']
        recovered = item['recovered']
        death = item['death']
        percentage = item['percentage']
        newCcase = item['newCcase']
        newFcase = item['newFcase']

        writer.writerow([
            countryName,
            newCase,
            totalCase,
            recovered,
            death,
            percentage,
            newCcase,
            newFcase
        ])