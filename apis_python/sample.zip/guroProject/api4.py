import requests
import json

# Corona-19-API
# API 사이트 : https://github.com/dhlife09/Corona-19-API

url = 'https://api.corona-19.kr/korea/?'
serviceKey = 'serviceKey=9kcdxuvKJWHmstOI8h2plBCPngrUR7NwZ'

res = requests.get(url + serviceKey)
print(res)
print(res.text)

item = json.loads(res.text)

with open('./response4.csv', mode='w', encoding='utf-8-sig') as f:
    TotalCase = '"' + item['TotalCase'] + '"'
    TotalRecovered = '"' + item['TotalRecovered'] + '"'
    TotalDeath = '"' + item['TotalDeath'] + '"'
    NowCase = '"' + item['NowCase'] + '"'
    city1n = item['city1n']
    city2n = item['city2n']
    city3n = item['city3n']
    city4n = item['city4n']
    city5n = item['city5n']
    city1p = item['city1p']
    city2p = item['city2p']
    city3p = item['city3p']
    city4p = item['city4p']
    city5p = item['city5p']
    recoveredPercentage = item['recoveredPercentage']
    deathPercentage = item['deathPercentage']
    checkingCounter = '"' + item['checkingCounter'] + '"'
    checkingPercentage = item['checkingPercentage']
    caseCount = '"' + item['caseCount'] + '"'
    casePercentage = item['casePercentage']
    notcaseCount = '"' + item['notcaseCount'] + '"'
    notcasePercentage = item['notcasePercentage']
    TotalChecking = '"' + item['TotalChecking'] + '"'
    TodayRecovered = item['TodayRecovered']
    TodayDeath = item['TodayDeath']
    TotalCaseBefore = item['TotalCaseBefore']
    source = item['source']
    updateTime = item['updateTime']
    resultMessage = item['resultMessage']

    f.write('국내 확진자 수 (TotalCase),' + TotalCase + '\n')
    f.write('국내 완치자 수 (TotalRecovered),' + TotalRecovered + '\n')
    f.write('국내 사망자 수 (TotalDeath),' + TotalDeath + '\n')
    f.write('국내 격리자 수 (NowCase),' + NowCase + '\n')
    f.write('시도별 확진자 현황 [이름] (확진자 많은 순) (city1n),' + city1n + '\n')
    f.write('시도별 확진자 현황 [이름] (city2n),' + city2n + '\n')
    f.write('시도별 확진자 현황 [이름] (city3n),' + city3n + '\n')
    f.write('시도별 확진자 현황 [이름] (city4n),' + city4n + '\n')
    f.write('시도별 확진자 현황 [이름] (city5n),' + city5n + '\n')
    f.write('시도별 확진환자 현황 [퍼센트] (city1p),' + city1p + '\n')
    f.write('시도별 확진환자 현황 [퍼센트] (city2p),' + city2p + '\n')
    f.write('시도별 확진환자 현황 [퍼센트] (city3p),' + city3p + '\n')
    f.write('시도별 확진환자 현황 [퍼센트] (city4p),' + city4p + '\n')
    f.write('시도별 확진환자 현황 [퍼센트] (city5p),' + city5p + '\n')
    f.write('국내 완치율 (recoveredPercentage),' + str(recoveredPercentage) + '\n')
    f.write('국내 사망률 (deathPercentage),' + str(deathPercentage) + '\n')
    f.write('국내 검사중 [명] (checkingCounter),' + checkingCounter + '\n')
    f.write('국내 검사중 [퍼센트] (checkingPercentage),' + checkingPercentage + '\n')
    f.write('국내 검사결과 양성 [명] (caseCount),' + caseCount + '\n')
    f.write('국내 검사결과 양성 [퍼센트] (casePercentage),' + casePercentage + '\n')
    f.write('국내 검사결과 음성 [명] (notcaseCount),' + notcaseCount + '\n')
    f.write('국내 검사결과 음성 [퍼센트] (notcasePercentage),' + notcasePercentage + '\n')
    f.write('총 검사완료 수 (TotalChecking),' + TotalChecking + '\n')
    f.write('오늘 하루 완치자수 (TodayRecovered),' + TodayRecovered + '\n')
    f.write('오늘 하루 사망자수 (TodayDeath),' + TodayDeath + '\n')
    f.write('전날 대비 환자수 (TotalCaseBefore),' + TotalCaseBefore + '\n')
    f.write('데이터 수집 방법 (source),' + source + '\n')
    f.write('정보 업데이트 기준 (updateTime),' + updateTime + '\n') # 00시 정보로 오전 10시경 자동으로 업데이트 됩니다.
    f.write('API 처리 결과 (resultMessage),' + resultMessage + '\n')
